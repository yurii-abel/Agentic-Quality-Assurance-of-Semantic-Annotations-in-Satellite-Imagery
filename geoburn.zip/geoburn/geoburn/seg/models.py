"""Segmentation back-ends behind one interface.

PixelEnsembleSegmenter  - runs anywhere (scikit-learn). Weakly supervised: it is trained per scene on
                          high-confidence seeds from the spectral baseline, so it is NOT independent
                          evidence. It adds multi-band and spatial-context information and, through
                          its members, a disagreement signal (adapted from Augmented Ensemble Ranking).
PrithviBurnScarSegmenter - adapter slot for an externally trained burn-scar model. Not executed in
                          this repository's tests; it refuses to run rather than pretend.
"""
from __future__ import annotations
import numpy as np
from scipy import ndimage as ndi
from ..rs import indices as ix
from ..data.base import BANDS


class SegmenterUnavailable(RuntimeError):
    pass


def feature_stack(post, pre=None):
    f, names = [], []
    for b in BANDS:
        f.append(post.bands[b]); names.append(b)
    nbr, ndv = ix.nbr(post.bands["nir08"], post.bands["swir22"]), ix.ndvi(post.bands["nir08"], post.bands["red"])
    f += [nbr, ndv, ix.nbr2(post.bands["swir16"], post.bands["swir22"])]; names += ["nbr", "ndvi", "nbr2"]
    for nm, a in (("nir08", post.bands["nir08"]), ("swir22", post.bands["swir22"]), ("nbr", nbr)):
        a0 = np.nan_to_num(a)
        m = ndi.uniform_filter(a0, 5)
        f += [m, np.sqrt(np.maximum(ndi.uniform_filter(a0 * a0, 5) - m * m, 0))]; names += [f"{nm}_mean5", f"{nm}_std5"]
    if pre is not None:
        for b in ("red", "nir08", "swir16", "swir22"):
            f.append(post.bands[b] - pre.bands[b]); names.append(f"d_{b}")
        f.append(ix.nbr(pre.bands["nir08"], pre.bands["swir22"]) - nbr); names.append("dnbr")
    return np.stack([np.nan_to_num(a).astype("float32") for a in f], -1), names


class PixelEnsembleSegmenter:
    name = "pixel-ensemble (weakly supervised, HistGradientBoosting)"

    def __init__(self, members=6, samples_per_member=20000, seed=7):
        self.k, self.n, self.seed = members, samples_per_member, seed

    def predict(self, post, pre, p_spectral, valid):
        from sklearn.ensemble import HistGradientBoostingClassifier
        X, names = feature_stack(post, pre)
        H, W, F = X.shape
        Xf, p = X.reshape(-1, F), np.nan_to_num(p_spectral, nan=0.5).ravel()
        v = valid.ravel()
        pos, neg = np.flatnonzero(v & (p > 0.9)), np.flatnonzero(v & (p < 0.1))
        if min(len(pos), len(neg)) < 200:
            raise SegmenterUnavailable(f"too few confident seeds (burned={len(pos)}, unburned={len(neg)})")
        rng, probs = np.random.default_rng(self.seed), []
        for k in range(self.k):
            half = self.n // 2
            idx = np.concatenate([rng.choice(pos, half, replace=len(pos) < half),
                                  rng.choice(neg, half, replace=len(neg) < half)])
            cols = np.sort(rng.choice(F, max(4, int(0.7 * F)), replace=False))   # feature bagging
            gain = rng.normal(1.0, 0.05, size=(len(idx), len(cols))).astype("float32")  # radiometric jitter
            y = np.r_[np.ones(half), np.zeros(half)]
            m = HistGradientBoostingClassifier(max_iter=40, max_depth=4, learning_rate=0.15, random_state=k)
            m.fit(Xf[idx][:, cols] * gain, y)
            probs.append(m.predict_proba(Xf[:, cols])[:, 1].astype("float32"))
        P = np.stack(probs)
        mean = np.where(v, P.mean(0), np.nan).reshape(H, W)
        var_bin = np.where(v, (P > 0.5).astype("float32").var(0), np.nan).reshape(H, W)
        return {"p_seg": mean.astype("float32"), "var_seg": var_bin.astype("float32"),
                "std_prob": np.where(v, P.std(0), np.nan).reshape(H, W).astype("float32"),
                "members": self.k, "features": names, "seeds": {"burned": int(len(pos)), "unburned": int(len(neg))},
                "model": self.name, "independent_of_baseline": False}


class PrithviBurnScarSegmenter:
    """Slot for ibm-nasa-geospatial Prithvi-EO burn-scar weights (HLS 6-band, 30 m, 512 px chips).

    Wiring it up requires torch + terratorch, a local weights file, resampling to 30 m and the
    model's band order/normalisation. None of that was available or verified where this code was
    written, so the adapter only checks prerequisites.
    """
    name = "prithvi-eo burn scar (adapter, unverified)"

    def predict(self, *a, **k):
        try:
            import torch, terratorch  # noqa: F401
        except ImportError as e:
            raise SegmenterUnavailable("Prithvi adapter needs torch and terratorch plus local weights") from e
        raise SegmenterUnavailable("Prithvi adapter is an interface only; inference has not been implemented or validated")


def hybrid(p_spectral, p_seg, valid, low=0.35, high=0.65):
    """Geometric-mean fusion + hysteresis: a pixel needs support from both sources to seed a region."""
    from ..rs.burn import hysteresis
    p = np.sqrt(np.clip(np.nan_to_num(p_spectral), 0, 1) * np.clip(np.nan_to_num(p_seg), 0, 1)).astype("float32")
    p = np.where(valid, p, np.nan)
    return p, hysteresis(p, low, high, valid)
